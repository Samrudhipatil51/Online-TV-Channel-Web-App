const arrows = document.querySelectorAll(".arrow");
const serialLists = document.querySelectorAll(".serial-list");

arrows.forEach((arrow, i) => {
  const itemNumber = serialLists[i].querySelectorAll("img").length;
  let clickCounter = 0;
  arrow.addEventListener("click", () => {
    const ratio = Math.floor(window.innerWidth / 270);
    clickCounter++;
    if (itemNumber - (6 + clickCounter) + (6 - ratio) >= 0) {
      serialLists[i].style.transform = `translateX(${
        serialLists[i].computedStyleMap().get("transform")[0].x.value - 300
      }px)`;
    } else {
      serialLists[i].style.transform = "translateX(0)";
      clickCounter = 0;
    }
  });

  console.log(Math.floor(window.innerWidth / 270));
});

//TOGGLE

const ball = document.querySelector(".toggle-ball");
const items = document.querySelectorAll(
  ".container,.serial-list-title,.navbar-container,.sidebar,.left-menu-icon,.toggle"
);

ball.addEventListener("click", () => {
  items.forEach((item) => {
    item.classList.toggle("active");
  });
  ball.classList.toggle("active");
});